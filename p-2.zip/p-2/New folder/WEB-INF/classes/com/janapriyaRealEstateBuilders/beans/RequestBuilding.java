package com.janapriyaRealEstateBuilders.beans;
import java.io.Serializable;

public class RequestBuilding implements Serializable{
	
	private String userName;
	private String buildingId;
	
	public RequestBuilding(){
		
	}
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(String buildingId) {
		this.buildingId = buildingId;
	}
	

}
