package com.janapriyaRealEstateBuilders.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.janapriyaRealEstateBuilders.beans.Building;
import com.janapriyaRealEstateBuilders.services.BuildingService;

/**
 * Servlet implementation class BuildingController
 */
public class BuildingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuildingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("in building controller");
		String buildingId=request.getParameter("buildingId");
		String buildingName=request.getParameter("buildingName");
		String userName=request.getParameter("userName");
		String cost=request.getParameter("cost");
		String rooms=request.getParameter("rooms");
		String address=request.getParameter("address");
		
		Building building=new Building();
		
		building.setBuildingId(buildingId);
		building.setBuildingName(buildingName);
		building.setUserName(userName);
		building.setCost(cost);
		building.setRooms(rooms);
		building.setAddress(address);
		
		BuildingService buildingService=new BuildingService();
		try{
			buildingService.addNewBuilding(building);
			}   
			catch(ClassNotFoundException ce ){
			           
			ce.printStackTrace();
			           // append message to log file
			       }
			      
			 catch(SQLException se){
			           se.printStackTrace( );
			           // append message to log file
			       }
			     
			       
		    request.setAttribute("message", "success");
			getServletContext().getRequestDispatcher("/AddBuilding.jsp").include(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
