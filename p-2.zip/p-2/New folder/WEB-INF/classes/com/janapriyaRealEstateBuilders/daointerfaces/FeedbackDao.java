package com.janapriyaRealEstateBuilders.daointerfaces;

import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Feedback;

public interface FeedbackDao {

	public abstract void sendFeedback(Feedback feedBack) throws ClassNotFoundException, SQLException;

}

