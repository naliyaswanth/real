package com.janapriyaRealEstateBuilders.daoimplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Feedback;
import com.janapriyaRealEstateBuilders.daointerfaces.FeedbackDao;
import com.janapriyaRealEstateBuilders.utilities.DatabaseConnectionUtility;

public class FeedbackDaoImplementation implements FeedbackDao{

	@Override
	public void sendFeedback(Feedback feedBack) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
	       
		 PreparedStatement psmt = con.prepareStatement("insert into res_feedback values(?,?)");
		         
		psmt.setString(1, feedBack.getUserName());
		         
		psmt.setString(2, feedBack.getFeedback());
		         
		psmt.executeUpdate();
        
		DatabaseConnectionUtility.closeConnection(con);
	}

}
