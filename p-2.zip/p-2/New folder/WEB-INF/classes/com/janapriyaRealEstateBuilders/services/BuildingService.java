package com.janapriyaRealEstateBuilders.services;

import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Building;
import com.janapriyaRealEstateBuilders.daoimplementations.BuildingDaoImplementation;
import com.janapriyaRealEstateBuilders.daointerfaces.BuildingDao;


public class BuildingService {

	public void addNewBuilding(Building building) throws ClassNotFoundException, SQLException{
	       
		 BuildingDao buildingDao =new BuildingDaoImplementation();
		       
		 buildingDao.addNewBuilding(building);

		    }
}
