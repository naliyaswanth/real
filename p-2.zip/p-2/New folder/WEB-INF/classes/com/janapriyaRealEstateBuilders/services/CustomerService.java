package com.janapriyaRealEstateBuilders.services;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Customer;
import com.janapriyaRealEstateBuilders.daoimplementations.CustomerDaoImplementation;
import com.janapriyaRealEstateBuilders.daointerfaces.CustomerDao;

public class CustomerService {

	public void addNewCustomer(Customer customer) throws ClassNotFoundException, SQLException{
	       
		 CustomerDao customerDao =new CustomerDaoImplementation();
		       
		 customerDao.addNewCustomer(customer);

		    }

	public ResultSet getCustomerDetails(Customer customer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		 CustomerDao customerDao =new CustomerDaoImplementation();
	       
		 ResultSet rs=customerDao.getCustomerDetails(customer);
		 return rs;
	}

	public void updateCustomerProfile(Customer customer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		 CustomerDao customerDao =new CustomerDaoImplementation();
	       
		 customerDao.updateCustomerProfile(customer);
	}

	public void approveCustomer(Customer customer) throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
		CustomerDao customerDao =new CustomerDaoImplementation();
	       
		 customerDao.approveCustomer(customer);
		
	}

	public ResultSet getCustomerDetailsAdmin(Customer customer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		CustomerDao customerDao =new CustomerDaoImplementation();
	       
		 ResultSet rs=customerDao.getCustomerDetailsAdmin(customer);
		 return rs;
	}

	public void mapCustomerToBuilding(Customer customer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		CustomerDao customerDao =new CustomerDaoImplementation();
	       
		 customerDao.mapCustomerToBuilding(customer);
	}

}
