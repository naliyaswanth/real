package com.RealEstateBuilders1.controllers;

import  com.RealEstateBuilders1.beans.RegisterBean;
import com.RealEstateBuilders1.service.deleteService;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DeleteController {

	@Autowired
    private deleteService empService;
	

    public void setEmpService(deleteService empService) {
		this.empService = empService;
	}

	@RequestMapping(value="/delete.html", method = RequestMethod.POST)
    public ModelAndView insert(@ModelAttribute("cmdEmp") RegisterBean rb) 
    {
    	System.out.println("In Controller.....Before");
    	
        empService.deleteDetails(rb);
        
        System.out.println("In Controller.....After");
        
        return new ModelAndView("deleteSuccess");
    }

    
}
