package com.RealEstateBuilders1.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.RealEstateBuilders1.beans.BuildingInformationBean;
import com.RealEstateBuilders1.service.BuildingService;

@Controller
public class BuildingInformationController {

	@Autowired
    private BuildingService empService;
	

    public void setEmpService(BuildingInformationBean bif) {
		this.empService = empService;
	}

	@RequestMapping(value="/insertbuildingdetails.html", method = RequestMethod.POST)
    public ModelAndView insert(@ModelAttribute("cmdEmp") BuildingInformationBean bif) 
    {
    	System.out.println("In Controller.....Before");
    	
        empService.insertBuildingDetails(bif);
        
        System.out.println("In Controller.....After");
        
        return new ModelAndView("success");
    }

    
}
