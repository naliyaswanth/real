package com.RealEstateBuilders1.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.RealEstateBuilders1.beans.RetriveBean;

public class RetriveDAO
{
	
		private HibernateTemplate ht;
		public List validate(RetriveBean lb)
		{
			
			List l;
			l=ht.find("from RetriveBean where customerName='"+lb.getCustomerName()+"'"); 
			System.out.println("In Dao Implementation");
			return l;
		}
		public void setHt(HibernateTemplate ht)
		{
			this.ht=ht;
		}
		public HibernateTemplate getHt()
		{
			return ht;
		}

	}

