package com.RealEstateBuilders1.service;

import com.RealEstateBuilders1.beans.RegisterBean;
import com.RealEstateBuilders1.dao.RegisterDAOImplementation;

public class RegisterServiceImplementation implements RegisterService {

	private RegisterDAOImplementation registerDAO;

	@Override
	public void insertCustomer(RegisterBean rb) 
	{
		System.out.println("RegisterServiceImp insertcustomer method");
		//System.out.println("insertEmp method of EmpServiceImpl method!!!");
		registerDAO.insertCustomer(rb);
	}
	
	public void setRegisterDAO(RegisterDAOImplementation registerDAO) 
	{
		System.out.println("RegisterServiceImp  setRegisterDao method");
        this.registerDAO = registerDAO;
    }

}
