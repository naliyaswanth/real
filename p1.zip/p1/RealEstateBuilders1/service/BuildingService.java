package com.RealEstateBuilders1.service;

import com.RealEstateBuilders1.beans.BuildingInformationBean;
import com.RealEstateBuilders1.dao.BuildingDAO;



public class BuildingService 
{

	private BuildingDAO empDAO;

	
	public void insertBuildingDetails(BuildingInformationBean rb) {
		
		System.out.println("insertEmp method of EmpServiceImpl method!!!");
        empDAO.insertBuildingDetails(rb);
	}
	
	public void setEmpDAO(BuildingDAO empDAO) {
        this.empDAO = empDAO;
    }

}
