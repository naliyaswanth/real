package com.RealEstateBuilders1.beans;

import java.io.Serializable;

public class BuildingInformationBean implements Serializable
{
    private String buildingName;
    private String buildingPrice;
    private String buildingType;
    private String buildingLocation;
    private String buildingArea;
	public BuildingInformationBean() {
		super();
	}
	public BuildingInformationBean(String buildingName, String buildingPrice,
			String buildingType, String buildingLocation, String buildingArea) {
		super();
		this.buildingName = buildingName;
		this.buildingPrice = buildingPrice;
		this.buildingType = buildingType;
		this.buildingLocation = buildingLocation;
		this.buildingArea = buildingArea;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getBuildingPrice() {
		return buildingPrice;
	}
	public void setBuildingPrice(String buildingPrice) {
		this.buildingPrice = buildingPrice;
	}
	public String getBuildingType() {
		return buildingType;
	}
	public void setBuildingType(String buildingType) {
		this.buildingType = buildingType;
	}
	public String getBuildingLocation() {
		return buildingLocation;
	}
	public void setBuildingLocation(String buildingLocation) {
		this.buildingLocation = buildingLocation;
	}
	public String getBuildingArea() {
		return buildingArea;
	}
	public void setBuildingArea(String buildingArea) {
		this.buildingArea = buildingArea;
	}
   
   




}
